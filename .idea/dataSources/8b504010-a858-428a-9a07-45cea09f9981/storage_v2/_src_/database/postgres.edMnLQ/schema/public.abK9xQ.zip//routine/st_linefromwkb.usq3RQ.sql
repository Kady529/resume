create function st_linefromwkb(bytea) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT CASE WHEN geometrytype(ST_GeomFromWKB($1)) = 'LINESTRING'
	THEN ST_GeomFromWKB($1)
	ELSE NULL END

$$;

comment on function st_linefromwkb(bytea) is 'args: WKB - Makes a LINESTRING from WKB with the given SRID';

alter function st_linefromwkb(bytea) owner to postgres;

