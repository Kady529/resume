create function st_line_substring(geometry, double precision, double precision) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT _postgis_deprecate('ST_Line_Substring', 'ST_LineSubstring', '2.1.0');
     SELECT ST_LineSubstring($1, $2, $3);
$$;

alter function st_line_substring(geometry, double precision, double precision) owner to postgres;

