create function st_multipolygonfromtext(text, integer) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT ST_MPolyFromText($1, $2)
$$;

alter function st_multipolygonfromtext(text, integer) owner to postgres;

