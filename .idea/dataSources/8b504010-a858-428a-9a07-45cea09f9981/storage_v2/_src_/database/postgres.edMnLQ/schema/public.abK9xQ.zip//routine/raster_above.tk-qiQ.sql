create function raster_above(raster, raster) returns boolean
    immutable
    strict
    language sql
as
$$
select $1::geometry |>> $2::geometry
$$;

alter function raster_above(raster, raster) owner to postgres;

