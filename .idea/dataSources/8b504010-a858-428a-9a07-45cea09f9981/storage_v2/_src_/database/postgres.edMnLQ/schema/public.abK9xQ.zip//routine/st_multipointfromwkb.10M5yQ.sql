create function st_multipointfromwkb(bytea) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT CASE WHEN geometrytype(ST_GeomFromWKB($1)) = 'MULTIPOINT'
	THEN ST_GeomFromWKB($1)
	ELSE NULL END

$$;

alter function st_multipointfromwkb(bytea) owner to postgres;

