create function st_mlinefromtext(text) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT CASE WHEN geometrytype(ST_GeomFromText($1)) = 'MULTILINESTRING'
	THEN ST_GeomFromText($1)
	ELSE NULL END

$$;

comment on function st_mlinefromtext(text) is 'args: WKT - Return a specified ST_MultiLineString value from WKT representation.';

alter function st_mlinefromtext(text) owner to postgres;

