create function st_multilinefromwkb(bytea) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT CASE WHEN geometrytype(ST_GeomFromWKB($1)) = 'MULTILINESTRING'
	THEN ST_GeomFromWKB($1)
	ELSE NULL END

$$;

alter function st_multilinefromwkb(bytea) owner to postgres;

