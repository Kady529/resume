create function geometry_contained_by_raster(geometry, raster) returns boolean
    immutable
    strict
    language sql
as
$$
select $1 @ $2::geometry
$$;

alter function geometry_contained_by_raster(geometry, raster) owner to postgres;

