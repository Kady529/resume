create function st_pixelaspolygons(rast raster, band integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, OUT geom geometry, OUT val double precision, OUT x integer, OUT y integer) returns SETOF record
    immutable
    strict
    language sql
as
$$
SELECT geom, val, x, y FROM _st_pixelaspolygons($1, $2, NULL, NULL, $3)
$$;

comment on function st_pixelaspolygons(raster, integer, boolean, out geometry, out double precision, out integer, out integer) is 'args: rast, band=1, exclude_nodata_value=TRUE - Returns the polygon geometry that bounds every pixel of a raster band along with the value, the X and the Y raster coordinates of each pixel.';

alter function st_pixelaspolygons(raster, integer, boolean, out geometry, out double precision, out integer, out integer) owner to postgres;

