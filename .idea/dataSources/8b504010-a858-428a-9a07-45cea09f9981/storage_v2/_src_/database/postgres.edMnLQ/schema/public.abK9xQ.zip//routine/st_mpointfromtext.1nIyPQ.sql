create function st_mpointfromtext(text, integer) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT CASE WHEN geometrytype(ST_GeomFromText($1, $2)) = 'MULTIPOINT'
	THEN ST_GeomFromText($1, $2)
	ELSE NULL END

$$;

comment on function st_mpointfromtext(text, integer) is 'args: WKT, srid - Makes a Geometry from WKT with the given SRID. If SRID is not give, it defaults to 0.';

alter function st_mpointfromtext(text, integer) owner to postgres;

