create function st_transscale(geometry, double precision, double precision, double precision, double precision) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT ST_Affine($1,  $4, 0, 0,  0, $5, 0,
		0, 0, 1,  $2 * $4, $3 * $5, 0)
$$;

comment on function st_transscale(geometry, double precision, double precision, double precision, double precision) is 'args: geomA, deltaX, deltaY, XFactor, YFactor - Translates the geometry using the deltaX and deltaY args, then scales it using the XFactor, YFactor args, working in 2D only.';

alter function st_transscale(geometry, double precision, double precision, double precision, double precision) owner to postgres;

