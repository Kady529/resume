create function st_mpolyfromwkb(bytea) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT CASE WHEN geometrytype(ST_GeomFromWKB($1)) = 'MULTIPOLYGON'
	THEN ST_GeomFromWKB($1)
	ELSE NULL END

$$;

alter function st_mpolyfromwkb(bytea) owner to postgres;

